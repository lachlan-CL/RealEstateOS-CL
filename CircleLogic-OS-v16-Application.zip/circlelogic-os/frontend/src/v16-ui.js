/* Real Estate Hub 16.0: dashboard customisation and interaction layer.
   This file does not call or modify the v14 backend or integration APIs. */
'use strict';
(function () {
  const oldShell=window.ReHubV15.shell;
  const oldDashboard=window.ReHubV15.dashboardPage;
  const escapeHTML=v=>String(v??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const glyph=(name,size=18)=>window.icon(name,size);
  const catalog=[
    {id:'financial',label:'Revenue & performance',icon:'chart',cat:'Analytics'},
    {id:'listings',label:'Active listings',icon:'home',cat:'Listings'},
    {id:'contacts',label:'Contacts & CRM',icon:'contract',cat:'CRM'},
    {id:'calendar',label:'Calendar & tasks',icon:'calendar',cat:'Tasks'},
    {id:'enquiries',label:'Latest enquiries',icon:'mail',cat:'CRM'},
    {id:'buyers',label:'Buyer engagement',icon:'users',cat:'CRM'},
    {id:'market',label:'Market activity',icon:'pulse',cat:'Analytics'},
    {id:'pipeline',label:'Sales pipeline',icon:'chart',cat:'Analytics'},
    {id:'propertymgmt',label:'Property management',icon:'building',cat:'Listings'},
    {id:'marketing',label:'Marketing performance',icon:'megaphone',cat:'Analytics'}
  ];
  const byId=Object.fromEntries(catalog.map(x=>[x.id,x]));
  const titleMap={
    'Revenue performance':'financial','Recent listings':'listings','Latest enquiries':'enquiries',
    'Tasks and upcoming appointments':'calendar','Buyer engagement':'buyers','Market activity':'market',
    'Sales pipeline':'pipeline','Contacts and CRM':'contacts','Property management':'propertymgmt',
    'Marketing performance':'marketing'
  };
  const defaults={
    principal:['financial','listings','contacts','calendar','enquiries','buyers','market','pipeline','propertymgmt','marketing'],
    agent:['buyers','calendar','listings','enquiries','contacts','pipeline','market','financial','propertymgmt','marketing']
  };
  const role=()=>S.v15View==='agent'?'agent':'principal';
  const key=v=>'cl-v16-layout-'+v;
  function layout(v=role()){
    try{const saved=JSON.parse(localStorage.getItem(key(v)));if(Array.isArray(saved))return [...new Set(saved)].filter(x=>byId[x]);}catch{}
    return [...defaults[v]];
  }
  function save(ids,v=role()){
    try{localStorage.setItem(key(v),JSON.stringify([...new Set(ids)].filter(x=>byId[x])));}catch{}
  }
  let lastRemoved=null,editorSearch='',editorCategory='All',drag=null,detail=null,detailIndex=0,detailTab='overview';
  const money=n=>'$'+new Intl.NumberFormat('en-AU',{maximumFractionDigits:0}).format(Number(n)||0);
  const tinyAvatar=(value,n=0)=>`<span class="v16-person v16-person-${n%5}">${escapeHTML(String(value||'?').split(' ').map(x=>x[0]).slice(0,2).join('').toUpperCase())}</span>`;
  const propertyImg=i=>'/assets/property-preview-'+(i%3+1)+'.webp';
  const propKey=p=>String(p?.title||'');
  const moduleId=node=>titleMap[node.getAttribute('aria-label')||''];
  function moduleHTML(){
    const t=document.createElement('template');t.innerHTML=oldDashboard();
    const map={}; t.content.querySelectorAll('.v15-module').forEach(node=>{const id=moduleId(node);if(id)map[id]=node;});
    return map;
  }
  function decorate(node,id,{editor=false}={}){
    const item=byId[id];node.setAttribute('data-v16-module',id);
    node.setAttribute('data-v16-dashboard-item','');
    if(editor)node.classList.add('v16-editable');
    const head=node.querySelector('.v15-module-head');
    if(head){
      const handle=document.createElement('button');handle.className='v16-grab';handle.type='button';handle.draggable=true;handle.setAttribute('data-v16-grab',id);handle.title='Drag to reorder '+item.label;handle.setAttribute('aria-label','Drag '+item.label+' to reorder');handle.innerHTML='<span class="v16-dots">&#10247;</span>';
      head.insertBefore(handle,head.firstChild);
      if(editor){
        const controls=document.createElement('span');controls.className='v16-edit-controls';controls.innerHTML=`<button type="button" data-v16="move-up" data-id="${id}" aria-label="Move ${escapeHTML(item.label)} up" title="Move up">${glyph('up',14)}</button><button type="button" data-v16="move-down" data-id="${id}" aria-label="Move ${escapeHTML(item.label)} down" title="Move down">${glyph('down',14)}</button><button type="button" data-v16="remove-module" data-id="${id}" aria-label="Remove ${escapeHTML(item.label)}" title="Remove module">${glyph('trash',14)}</button>`;
        head.append(controls);
      }
    }
    return node;
  }
  function cardsHtml({editor=false}={}){
    const all=moduleHTML();return layout().map(id=>all[id]?decorate(all[id],id,{editor}).outerHTML:'').join('');
  }
  function dashboardPage(){
    const t=document.createElement('template');t.innerHTML=oldDashboard();
    const grid=t.content.querySelector('.v15-modules');
    if(grid){grid.classList.add('v16-modules');grid.innerHTML=cardsHtml();
      const graph=grid.querySelector('.v15-revenue-chart g');
      if(graph){const amounts=DEMO_FINANCIALS.months.map(r=>Number(r.value));amounts.forEach((value,i)=>{const bar=document.createElementNS('http://www.w3.org/2000/svg','rect');bar.setAttribute('x',String(i*125-15));bar.setAttribute('y',String((168-value/350*168).toFixed(1)));bar.setAttribute('width','30');bar.setAttribute('height',String((value/350*168).toFixed(1)));bar.setAttribute('fill',i%2?'#7763d9':'#2b70d7');bar.setAttribute('opacity','.31');bar.setAttribute('rx','3');graph.insertBefore(bar,graph.querySelector('path'));});}
    }
    const overview=t.content.querySelector('.v15-overview-line');
    if(overview){const button=document.createElement('button');button.className='v16-customise';button.setAttribute('data-nav','modules');button.innerHTML=glyph('settings',15)+' Customise';overview.append(button);}
    const more=t.content.querySelector('.v15-add-module');
    if(more){more.innerHTML=`<span>${glyph('plus',18)} Dashboard modules</span><button type="button" data-nav="modules">Manage layout ${glyph('arrow',14)}</button>`;}
    if(grid&&!grid.children.length)grid.innerHTML=`<section class="v16-empty-layout"><h3>Your dashboard is empty</h3><button type="button" data-nav="modules">Add modules</button></section>`;
    const foot=t.content.querySelector('.v15-footer');if(foot)foot.innerHTML='CircleLogic Real Estate Hub <span>Frontend v16.0 | v14 backend</span>';
    return t.innerHTML;
  }
  function shell(){
    oldShell();
    const nav=document.querySelector('.v15-sidebar .sidebar-nav');
    if(nav)nav.innerHTML=`<button class="nav-button v15-nav-button ${S.route==='dashboard'?'active':''}" data-nav="dashboard" ${S.route==='dashboard'?'aria-current="page"':''}><span class="nav-icon">${glyph('grid')}</span><span class="nav-label">Dashboard</span></button><button class="nav-button v15-nav-button ${S.route==='integrations'?'active':''}" data-nav="integrations" ${S.route==='integrations'?'aria-current="page"':''}><span class="nav-icon">${glyph('plug')}</span><span class="nav-label">Plugins</span></button><button class="nav-button v15-nav-button ${S.route==='modules'?'active':''}" data-nav="modules" ${S.route==='modules'?'aria-current="page"':''}><span class="nav-icon">${glyph('plus')}</span><span class="nav-label">New module</span></button>`;
    const release=document.querySelector('.v15-release-label');if(release)release.textContent='Frontend v16.0 | v14 backend';
    const settings=document.querySelector('.v15-sidebar-bottom > .v15-nav-button');if(settings)settings.remove();
    const brand=document.querySelector('.v15-sidebar .v15-logo');if(brand){brand.classList.add('v16-brand-colour');brand.querySelector('img')?.setAttribute('src','/assets/circlelogic-logo-original.svg');}
    const pageTitle=document.querySelector('.v15-topbar-left h1');if(pageTitle&&S.route==='modules')pageTitle.textContent='Real Estate Hub';
    const content=document.getElementById('page');if(content&&S.route==='modules')content.classList.add('v16-editor-page');
  }
  function editorPage(){
    const active=layout();const available=catalog.filter(c=>!active.includes(c.id));
    return `<section class="v16-editor-head"><div><h2>Dashboard layout</h2><span class="v16-editor-caption">${active.length} modules on ${role()==='principal'?'Principal':'Agent'} dashboard</span></div><div class="v16-editor-actions"><button data-v16="reset-layout" class="v16-quiet-button">Reset layout</button><button data-v16="preview-dashboard" class="v16-quiet-button">${glyph('eye',16)} Preview</button><button data-v16="save-layout" class="v16-primary-button">${glyph('check',16)} Save layout</button></div></section><div class="v16-editor-shell"><aside class="v16-library"><h3>${glyph('grid',18)} Module library</h3><label class="v16-library-search">${glyph('search',16)}<input id="v16-library-search" type="search" placeholder="Search modules" value="${escapeHTML(editorSearch)}"></label><div class="v16-library-tabs">${['All','Listings','Analytics','CRM','Tasks'].map(cat=>`<button data-v16="category" data-category="${cat}" class="${cat===editorCategory?'selected':''}">${cat}</button>`).join('')}</div><div id="v16-library-items" class="v16-library-items">${libraryList()}</div></aside><div class="v16-editor-work"><div class="v16-layout-label"><span>${glyph('grid',18)} ${role()==='principal'?'Principal':'Agent'} workspace</span><small>Drag by the six-dot handle to rearrange. Drop into the red zone to remove.</small></div><div class="v16-editor-grid" data-v16-layout-grid>${cardsHtml({editor:true})}<div class="v16-drop-add" data-v16-drop-add>${glyph('plus',25)}<span>Drop a module here</span></div></div><div class="v16-bin" data-v16-bin><div class="v16-bin-illustration"><span class="v16-bin-paper"></span><span class="v16-bin-teeth"></span>${glyph('trash',26)}</div><strong>Remove module</strong><span>Drag a module here to remove it from this view</span></div>${lastRemoved&&lastRemoved.view===role()?`<button class="v16-undo" data-v16="undo-removal">${glyph('undo',15)} Undo removal of ${escapeHTML(byId[lastRemoved.id]?.label||'module')}</button>`:''}</div></div>`;
  }
  function libraryList(){
    const needle=editorSearch.toLowerCase().trim();
    const matches=catalog.filter(item=>(editorCategory==='All'||item.cat===editorCategory)&&(!needle||(item.label+' '+item.cat).toLowerCase().includes(needle)));
    return matches.length?matches.map(item=>`<div class="v16-library-item ${layout().includes(item.id)?'is-active':''}" data-v16-library-item="${item.id}"><span class="v16-library-icon">${glyph(item.icon,23)}</span><span class="v16-library-copy"><strong>${escapeHTML(item.label)}</strong><small>${escapeHTML(item.cat)}</small></span><button type="button" data-v16="add-module" data-id="${item.id}" aria-label="${layout().includes(item.id)?'Already added':'Add'} ${escapeHTML(item.label)}" ${layout().includes(item.id)?'disabled':''}>${layout().includes(item.id)?glyph('check',16):glyph('plus',17)}</button><span class="v16-library-grip" data-v16-library-grab="${item.id}" draggable="${!layout().includes(item.id)}" title="Drag to dashboard">&#10247;</span></div>`).join(''):'<p class="v16-library-none">No matching modules</p>';
  }
  function rerenderEditor(){if(S.route!=='modules')return;const page=document.getElementById('page');if(page)page.innerHTML=editorPage();}
  function rerenderDashboard(){if(S.route!=='dashboard')return;const page=document.getElementById('page');if(page)page.innerHTML=dashboardPage();}
  function insertModule(id,index){if(!byId[id])return;const current=layout().filter(x=>x!==id);current.splice(Math.min(Math.max(0,index),current.length),0,id);save(current);lastRemoved=null;rerenderEditor();rerenderDashboard();}
  function reorderModule(id,target,after){const current=layout().filter(x=>x!==id);const pos=current.indexOf(target);if(pos<0){current.push(id);}else{current.splice(pos+(after?1:0),0,id);}save(current);rerenderEditor();rerenderDashboard();}
  function removeModule(id,animated=false){const before=layout(),at=before.indexOf(id);if(at<0)return;lastRemoved={id,index:at,view:role()};const commit=()=>{save(before.filter(x=>x!==id));rerenderEditor();rerenderDashboard();};if(animated&&S.route==='modules'){
      const zone=document.querySelector('[data-v16-bin]');if(zone){zone.classList.add('v16-shredding');zone.insertAdjacentHTML('beforeend',`<span class="v16-shred-card">${escapeHTML(byId[id].label)}<i></i><i></i><i></i><i></i><i></i></span>`);setTimeout(commit,680);return;}}
    commit();
  }
  function updateDropState(clear=false){document.querySelectorAll('.v16-drag-over,.v16-bin-target,.v16-dragging').forEach(x=>x.classList.remove('v16-drag-over','v16-bin-target','v16-dragging'));if(clear)drag=null;}
  document.addEventListener('dragstart',e=>{
    const handle=e.target.closest('[data-v16-grab],[data-v16-library-grab]');if(!handle)return;
    const id=handle.dataset.v16Grab||handle.dataset.v16LibraryGrab;
    if(!id||(!handle.dataset.v16Grab&&layout().includes(id))){e.preventDefault();return;}
    drag={id,from:handle.dataset.v16Grab?'layout':'library'};
    e.dataTransfer.setData('text/plain',id);e.dataTransfer.effectAllowed='move';
    handle.closest('[data-v16-module],[data-v16-library-item]')?.classList.add('v16-dragging');
  });
  document.addEventListener('dragover',e=>{
    if(!drag)return;
    const bin=e.target.closest('[data-v16-bin]'),tile=e.target.closest('[data-v16-module]'),end=e.target.closest('[data-v16-drop-add]');
    if(bin&&drag.from==='layout'){e.preventDefault();e.dataTransfer.dropEffect='move';bin.classList.add('v16-bin-target');return;}
    if((tile&&tile.dataset.v16Module!==drag.id)||end){e.preventDefault();e.dataTransfer.dropEffect='move';tile?.classList.add('v16-drag-over');end?.classList.add('v16-drag-over');}
  });
  document.addEventListener('dragleave',e=>{if(e.target.closest('[data-v16-bin]')&&!e.relatedTarget?.closest?.('[data-v16-bin]'))e.target.closest('[data-v16-bin]').classList.remove('v16-bin-target');});
  document.addEventListener('drop',e=>{
    if(!drag)return;const event=drag;const bin=e.target.closest('[data-v16-bin]'),tile=e.target.closest('[data-v16-module]'),end=e.target.closest('[data-v16-drop-add]');
    if(bin&&event.from==='layout'){e.preventDefault();updateDropState();removeModule(event.id,true);drag=null;return;}
    if(tile&&tile.dataset.v16Module!==event.id){e.preventDefault();const id=tile.dataset.v16Module;const box=tile.getBoundingClientRect();const after=e.clientY>box.top+box.height/2;updateDropState();reorderModule(event.id,id,after);drag=null;return;}
    if(end){e.preventDefault();updateDropState();insertModule(event.id,layout().length);drag=null;return;}
    updateDropState(true);
  });
  document.addEventListener('dragend',()=>updateDropState(true));
  function updateLibrarySearch(value){editorSearch=value;const el=document.getElementById('v16-library-items');if(el)el.innerHTML=libraryList();}
  function stepIndex(index,max){return (index%max+max)%max;}
  const pct=(n,max)=>Math.max(0,Math.min(100,Math.round(Number(n)/(Number(max)||1)*100)));
  function chartSVG(data,colors=['#3998ff'],{maxValue,labels=true,height=210}={}){
    const w=650,h=height,pad=30,usable=h-48;
    const series=Array.isArray(data[0])?data:[data];const high=maxValue||Math.max(1,...series.flat());
    const positions=series.map(arr=>arr.map((v,i)=>[24+(i/Math.max(1,arr.length-1))*(w-40),22+usable*(1-Number(v)/high)]));
    return `<svg class="v16-chart-svg" viewBox="0 0 ${w} ${h}" role="img" aria-label="Illustrative data chart">${[0,1,2,3,4].map(i=>`<line x1="24" x2="635" y1="${22+i*usable/4}" y2="${22+i*usable/4}" stroke="#2a3c50" stroke-width="1"/>`).join('')}${positions.map((points,j)=>`<path d="M ${points.map(p=>p.join(' ')).join(' L ')}" fill="none" stroke="${colors[j%colors.length]}" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/>${points.map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3.4" fill="#0f1b2a" stroke="${colors[j%colors.length]}" stroke-width="2"/>`).join('')}`).join('')}${labels?'<text x="25" y="'+(h-4)+'" font-size="11" fill="#8c9cb1">Start</text><text x="630" y="'+(h-4)+'" font-size="11" fill="#8c9cb1" text-anchor="end">Recent</text>':''}</svg>`;
  }
  function detailHeader(sub='',tabs=[]){return `<div class="v16-detail-top"><span class="v16-detail-label">${escapeHTML(sub)}</span>${tabs.length?`<div class="v16-detail-tabs">${tabs.map(t=>`<button data-v16="detail-tab" data-tab="${t.key}" class="${detailTab===t.key?'selected':''}">${escapeHTML(t.label)}</button>`).join('')}</div>`:''}</div>`;}
  function counter(n,prefix='',suffix=''){return `<strong class="v16-count" data-v16-count="${Number(n)||0}" data-prefix="${escapeHTML(prefix)}" data-suffix="${escapeHTML(suffix)}">${escapeHTML(prefix)}${Number(n).toLocaleString('en-AU')}${escapeHTML(suffix)}</strong>`;}
  function metric(label,value,delta='',tone=''){return `<div class="v16-detail-stat"><span>${escapeHTML(label)}</span>${typeof value==='number'?counter(value,value>=1000?'$':''): `<strong>${escapeHTML(value)}</strong>`}${delta?`<small class="${tone}">${escapeHTML(delta)}</small>`:''}</div>`;}
  function legend(rows){return `<div class="v16-legend">${rows.map(([label,color])=>`<span><i style="background:${color}"></i>${escapeHTML(label)}</span>`).join('')}</div>`;}
  function plotBars(values,labels=[],color='#348cff'){
    const max=Math.max(...values,1);return `<div class="v16-bar-plot">${values.map((v,i)=>`<div class="v16-bar-col" title="${escapeHTML(labels[i]||i+1)}: ${escapeHTML(v)}"><span style="height:${Math.max(5,pct(v,max))}%;background:${color}"></span><small>${escapeHTML(labels[i]||i+1)}</small></div>`).join('')}</div>`;
  }
  function detailListings(){
    const total=DEMO_LISTINGS.length;const n=stepIndex(detailIndex,total),p=DEMO_LISTINGS[n];
    return `${detailHeader('LISTINGS  /  '+(n+1)+' OF '+total)}<div class="v16-listing-detail"><div class="v16-listing-main"><div class="v16-carousel"><button class="v16-carousel-arrow prev" data-v16="listing-prev" aria-label="Previous listing">${glyph('chevron',21)}</button><img src="${propertyImg(n)}" alt="Illustrative property at ${escapeHTML(p.title)}"><button class="v16-carousel-arrow next" data-v16="listing-next" aria-label="Next listing">${glyph('chevron',21)}</button><span class="v16-property-chip">${escapeHTML(p.stage||'Active')}</span><span class="v16-photo-count">${n+1} / ${total}</span></div><div class="v16-detail-property-title"><div><h3>${escapeHTML(p.title)}</h3><span>${escapeHTML(p.suburb)} | ${escapeHTML(p.summary)}</span></div><strong>${escapeHTML(p.price)}</strong></div><div class="v16-thumbnail-strip">${[n,n+1,n+2,n+3].map(i=>`<button data-v16="listing-pick" data-index="${i%total}" class="${i===n?'selected':''}" aria-label="View listing ${i%total+1}"><img src="${propertyImg(i)}" alt=""></button>`).join('')}</div></div><div class="v16-listing-insights"><div class="v16-detail-stat"><span>Price guide</span><strong>${escapeHTML(p.price)}</strong></div><div class="v16-mini-grid"><div><span>Campaign</span><strong>${escapeHTML(p.stage)}</strong></div><div><span>Agent</span><strong>${escapeHTML(p.agent)}</strong></div></div><div class="v16-side-section"><h4>Campaign activity</h4>${plotBars([18,24,16,30,39,31,47],['M','T','W','T','F','S','S'],'#449aff')}<small>Illustrative enquiry activity</small></div><div class="v16-side-section"><h4>Property status</h4><p>${escapeHTML(p.status)}</p></div><button class="v16-primary-button" data-action="demo-record" data-kind="listings" data-index="${n}">Open listing details ${glyph('arrow',16)}</button></div></div><div class="v16-detail-bottom"><div class="v16-side-section"><h4>Campaign trend</h4>${chartSVG([[12,16,20,19,27,29,37],[8,11,12,14,19,17,26]],['#3896ff','#24ceb5'],{height:172})}${legend([['Views','#3896ff'],['Enquiries','#24ceb5']])}</div><div class="v16-side-section"><h4>Recent enquiries</h4>${DEMO_ENQUIRIES.filter(r=>r.property===p.title).slice(0,4).map(r=>`<button class="v16-related-lead" data-action="open-panel" data-panel="enquiries"><span>${tinyAvatar(r.name)}</span><span><strong>${escapeHTML(r.name)}</strong><small>${escapeHTML(r.intent)}</small></span><small>${escapeHTML(r.received)}</small></button>`).join('')||'<p>No recent enquiries in the sample feed.</p>'}<button data-action="open-panel" data-panel="enquiries" class="v16-related-all">All enquiries ${glyph('arrow',13)}</button></div></div>`;
  }
  function detailFinancial(){
    const months=DEMO_FINANCIALS.months;const source=months.map(x=>x.value),tab=detailTab==='pipeline'?'pipeline':detailTab==='fees'?'fees':'revenue';
    const series=tab==='revenue'?source:tab==='pipeline'?source.map((x,i)=>Math.round(x*1.25+i*8)):source.map((x,i)=>Math.round(x*.32+(i%2)*8));
    return `${detailHeader('FINANCIALS  /  ILLUSTRATIVE DATA',[{key:'revenue',label:'Revenue'},{key:'pipeline',label:'Pipeline GCI'},{key:'fees',label:'PM fees'}])}<div class="v16-finance-stats">${metric('Revenue MTD',286400,'89.5% of target','positive')}${metric('Pipeline GCI',412800,'Agency opportunities','')}${metric('PM fees',86400,'Monthly recurring','')}</div><div class="v16-chart-paper"><div class="v16-chart-head"><h3>${tab==='revenue'?'Revenue trend':tab==='pipeline'?'Pipeline GCI trend':'Property management fees'}</h3><span>May to September</span></div>${chartSVG([series,source.map(x=>Math.round(x*.83))],['#448fff','#8c80a8'],{height:270})}${legend([[tab==='revenue'?'Revenue':tab==='pipeline'?'GCI':'Fees','#448fff'],['Comparison','#8c80a8']])}</div><div class="v16-financial-breakdown">${DEMO_FINANCIALS.breakdown.map(([label,value],i)=>`<div class="v16-breakdown-item"><span>${escapeHTML(label)}</span><strong>${escapeHTML(value)}</strong><div class="v16-track"><i style="width:${[68,38,20,90][i]}%;background:${['#459aff','#27d2b0','#9874ed','#f1a750'][i]}"></i></div></div>`).join('')}</div>`;
  }
  function peoplePanel(kind){
    let rows,title,subtitle;const isContacts=kind==='contacts';const isEnquiries=kind==='enquiries';
    if(isContacts){rows=DEMO_CONTACTS;title='Contact';subtitle='CRM'}
    else if(isEnquiries){rows=DEMO_ENQUIRIES.map((p,i)=>({title:p.name,suburb:p.property,score:p.score,status:p.intent,interest:p.source,received:p.received,originalIndex:i}));title='Lead';subtitle='ENQUIRIES'}
    else{rows=DEMO_BUYERS;title='Buyer';subtitle='BUYERS'}
    const n=Math.min(detailIndex,rows.length-1),p=rows[n]||{},label=p.title||p.name||'';
    const tags=isContacts?['All','Buyers','Sellers']:isEnquiries?['All','Recent','High intent']:['All','High intent','Active'];
    const filtered=rows.map((p,i)=>({...p,_idx:i})).filter(p=>detailTab==='recent'?p._idx<6:detailTab==='high'?p.score>=80:detailTab==='buyers'&&isContacts?/buyer/i.test(p.role):detailTab==='sellers'&&isContacts?/seller|vendor/i.test(p.role):true);
    return `${detailHeader(subtitle, tags.map((x,i)=>({key:['all',isContacts?'buyers':isEnquiries?'recent':'high',isContacts?'sellers':isEnquiries?'high':'recent'][i],label:x})))}<div class="v16-people-workspace"><div class="v16-selectable-list" data-v16-animated-list tabindex="0" aria-label="${title} records">${filtered.map((r,i)=>`<button data-v16="select-person" data-index="${r._idx}" class="v16-select-row ${r._idx===n?'active':''}" style="--v16-stagger:${Math.min(i,9)*38}ms"><span class="v16-row-index">${String(i+1).padStart(2,'0')}</span>${tinyAvatar(r.title,i)}<span class="v16-row-person"><strong>${escapeHTML(r.title)}</strong><small>${escapeHTML(isContacts?r.suburb:isEnquiries?r.suburb:r.interest)}</small></span>${r.score!=null?`<span class="v16-row-score" style="color:${r.score>=80?'#37ceaa':r.score>=60?'#f2b754':'#ed7187'}">${r.score}</span>`:''}<span class="v16-row-arrow">${glyph('arrow',14)}</span></button>`).join('')||'<p class="v16-no-results">No records in this filter.</p>'}</div><div class="v16-person-profile"><div class="v16-profile-head">${tinyAvatar(label,n)}<div><h3>${escapeHTML(label)}</h3><span>${escapeHTML(p.suburb||p.property||'')}</span></div><span class="v16-profile-badge">${escapeHTML(p.status||p.role||'Buyer')}</span></div><div class="v16-profile-values">${isContacts?`<div><span>Role</span><strong>${escapeHTML(p.role)}</strong></div><div><span>Status</span><strong>${escapeHTML(p.status)}</strong></div><div><span>Last contact</span><strong>${escapeHTML(p.last_touch)}</strong></div><div><span>Interest</span><strong>${escapeHTML(p.interest)}</strong></div>`:isEnquiries?`<div><span>Source</span><strong>${escapeHTML(p.interest)}</strong></div><div><span>Received</span><strong>${escapeHTML(p.received)}</strong></div><div><span>Intent score</span><strong>${p.score} / 100</strong></div><div><span>Property</span><strong>${escapeHTML(p.suburb)}</strong></div>`:`<div><span>Budget</span><strong>${escapeHTML(p.budget)}</strong></div><div><span>Preferred areas</span><strong>${escapeHTML(p.suburb)}</strong></div><div><span>Next step</span><strong>${escapeHTML(p.next_step)}</strong></div><div><span>Agent</span><strong>${escapeHTML(p.agent)}</strong></div>`}</div>${!isContacts?`<div class="v16-side-section"><h4>Engagement</h4><div class="v16-score-large"><strong>${p.score}</strong><span>/ 100</span></div><div class="v16-track"><i style="width:${p.score||0}%;background:${(p.score||0)>=80?'#2bd0a4':(p.score||0)>=55?'#ffbd57':'#f26c84'}"></i></div>${plotBars([29,37,34,51,48,59,Number(p.score)||65],['M','T','W','T','F','S','S'],'#388dff')}</div>`:`<div class="v16-side-section"><h4>Contact details</h4><p>${escapeHTML(p.email||'')}</p><p>${escapeHTML(p.phone||'')}</p></div>`}<button class="v16-primary-button" data-action="demo-record" data-kind="${isContacts?'contacts':isEnquiries?'contacts':'buyers'}" data-index="${isEnquiries?0:n}" ${isEnquiries?'disabled title="Demo lead has no CRM record"':''}>${isEnquiries?'Lead record preview':`Open ${title.toLowerCase()} record`} ${glyph('arrow',15)}</button></div></div>`;
  }
  function detailPipeline(){
    const total=DEMO_PIPELINE.length,n=stepIndex(detailIndex,total),p=DEMO_PIPELINE[n];
    return `${detailHeader('SALES PIPELINE')}<div class="v16-stepper">${DEMO_PIPELINE.map((s,i)=>`<button data-v16="select-stage" data-index="${i}" class="${i===n?'active':''}"><span class="v16-step-circle">${String(i+1).padStart(2,'0')}</span><span>${escapeHTML(s.stage)}</span></button>`).join('')}</div><div class="v16-pipeline-layout"><div class="v16-pipeline-focus"><span class="v16-detail-label">STAGE ${n+1} OF ${total}</span><h3>${escapeHTML(p.stage)}</h3><div class="v16-finance-stats">${metric('Opportunities',p.deals)}${metric('Volume',p.volume)}${metric('Expected GCI',p.gci)}</div><div class="v16-pipeline-plot">${plotBars(DEMO_PIPELINE.map(x=>x.deals),DEMO_PIPELINE.map((x,i)=>String(i+1)),'#448fff')}</div><div class="v16-step-buttons"><button data-v16="stage-prev" class="v16-quiet-button" ${n===0?'disabled':''}>${glyph('chevron',15)} Previous</button><button data-v16="stage-next" class="v16-primary-button" ${n===total-1?'disabled':''}>Next stage ${glyph('arrow',15)}</button></div></div><div class="v16-pipeline-rail"><h4>All stages</h4>${DEMO_PIPELINE.map((s,i)=>`<button data-v16="select-stage" data-index="${i}" class="${i===n?'active':''}"><span>${escapeHTML(s.stage)}</span><strong>${s.deals}</strong></button>`).join('')}</div></div>`;
  }
  function detailMarket(){
    const rows=DEMO_MARKET_TRENDS;const d=detailTab==='listings'?'listings':detailTab==='sales'?'sales':'enquiries';
    const values=rows.map(x=>x[d]);
    return `${detailHeader('MARKET INSIGHTS  /  ILLUSTRATIVE DATA',[{key:'enquiries',label:'Enquiries'},{key:'listings',label:'Listings'},{key:'sales',label:'Sales'}])}<div class="v16-finance-stats">${metric('Enquiries',rows.reduce((a,x)=>a+x.enquiries,0))}${metric('New listings',rows.reduce((a,x)=>a+x.listings,0))}${metric('Recorded sales',rows.reduce((a,x)=>a+x.sales,0))}</div><div class="v16-market-grid"><div class="v16-chart-paper"><h3>${d==='enquiries'?'Enquiry activity':d==='listings'?'New listings':'Sales volume'}</h3>${chartSVG([values,values.map((x,i)=>Math.round(x*.75+(i%3)*2))],['#38cbb9','#9479ec'],{height:266})}${legend([[d.charAt(0).toUpperCase()+d.slice(1),'#38cbb9'],['Comparison','#9479ec']])}</div><div class="v16-market-suburbs"><h4>Suburb snapshot</h4>${DEMO_MARKET_SUBURBS.map(r=>`<div><span><strong>${escapeHTML(r.suburb)}</strong><small>Median ${escapeHTML(r.median)}</small></span><span><b>${escapeHTML(r.change)}</b><small>${escapeHTML(r.dom)} DOM</small></span></div>`).join('')}</div></div>`;
  }
  function detailPM(){return `${detailHeader('PROPERTY MANAGEMENT  /  ILLUSTRATIVE DATA')}<div class="v16-pm-tiles">${DEMO_PM_STATS.map((p,i)=>`<div class="v16-pm-tile"><span>${escapeHTML(p.label)}</span><strong>${escapeHTML(p.value)}</strong><small>${escapeHTML(p.detail)}</small><i style="background:${['#298cf1','#28c7a2','#f0aa4c','#a57cff','#58a7f7','#25bab6'][i]}"></i></div>`).join('')}</div><div class="v16-detail-bottom"><div class="v16-side-section"><h4>Portfolio activity</h4>${chartSVG([[12,16,19,24,22,28,31],[8,11,13,12,18,17,24]],['#348ffc','#2acaac'],{height:220})}${legend([['Inspections','#348ffc'],['Maintenance','#2acaac']])}</div><div class="v16-side-section"><h4>Occupancy</h4><div class="v16-donut-wrap"><div class="v16-donut" style="--v16-percent:98.1%;--v16-donut-color:#32d3a8"><strong>98.1%</strong><span>Occupied</span></div><div class="v16-donut-info"><span>12 vacant properties</span><span>624 properties managed</span></div></div></div></div>`;}
  function detailMarketing(){
    const n=Math.min(detailIndex,DEMO_MARKETING.length-1),p=DEMO_MARKETING[n];
    return `${detailHeader('MARKETING  /  ILLUSTRATIVE DATA')}<div class="v16-marketing-grid"><div class="v16-marketing-choose"><h3>Campaigns</h3>${DEMO_MARKETING.map((r,i)=>`<button class="${i===n?'active':''}" data-v16="select-campaign" data-index="${i}"><span>${escapeHTML(r.campaign)}</span><strong>${escapeHTML(r.enquiries)} leads</strong></button>`).join('')}</div><div class="v16-marketing-data"><h3>${escapeHTML(p.campaign)}</h3><div class="v16-finance-stats">${metric('Views',p.views)}${metric('Enquiries',p.enquiries)}${metric('Cost per lead',p.cpl)}</div><div class="v16-side-section"><h4>Campaign results</h4>${plotBars([Number(p.views.replace(/,/g,'')),Number(p.saves)*18,Number(p.enquiries)*85],['Views','Saves','Leads'],'#438df4')}</div><div class="v16-detail-bottom"><div><span>Campaign spend</span><strong>${escapeHTML(p.spend)}</strong></div><div><span>Saved listings</span><strong>${escapeHTML(p.saves)}</strong></div></div></div></div>`;
  }
  function detailCalendar(){
    const events=(S.data?.calendar?.rows||[]).slice(0,30),n=Math.min(detailIndex,events.length-1),ev=events[n];
    return `${detailHeader('GOOGLE CALENDAR  /  '+(events.length?'CONNECTED EVENTS':'NO IMPORTED EVENTS'))}<div class="v16-calendar-detail"><div class="v16-selectable-list v16-calendar-events" data-v16-animated-list tabindex="0">${events.length?events.map((r,i)=>{const dt=dateObj(r.start,r.timezone);return `<button data-v16="select-event" data-index="${i}" class="v16-select-row ${i===n?'active':''}" style="--v16-stagger:${i*28}ms"><span class="v16-row-index">${escapeHTML(dt?fmtDate(dt,{day:'numeric',month:'short'}):'--')}</span><span class="v16-row-person"><strong>${escapeHTML(r.title)}</strong><small>${escapeHTML(r.all_day?'All day':dt?fmtDate(dt,{hour:'numeric',minute:'2-digit'}):'')}${r.location?' | '+escapeHTML(r.location):''}</small></span><span class="v16-row-arrow">${glyph('arrow',14)}</span></button>`;}).join(''):`<div class="v16-no-calendar"><div>${glyph('calendar',28)}</div><h3>No imported events</h3><p>Connect Google Calendar in Plugins to display live appointments.</p><button data-connect="google" class="v16-primary-button">Open Google Calendar setup</button></div>`}</div><div class="v16-calendar-info">${ev?`<span class="v16-detail-label">EVENT DETAIL</span><h3>${escapeHTML(ev.title)}</h3><div class="v16-profile-values"><div><span>Start</span><strong>${escapeHTML(fmtDate(dateObj(ev.start,ev.timezone),{weekday:'short',day:'numeric',month:'long',hour:'numeric',minute:'2-digit'}))}</strong></div><div><span>Location</span><strong>${escapeHTML(ev.location||'Not provided')}</strong></div><div><span>Source</span><strong>${escapeHTML(ev.calendar_source||'Google Calendar')}</strong></div></div><button data-action="record" data-panel="calendar" data-index="${n}" class="v16-primary-button">Open event details ${glyph('arrow',15)}</button>`:`<h3>Connect your calendar</h3><p>Only imported events from your connected Google Calendar appear here. Sample appointments are not substituted.</p>`}</div></div>`;
  }
  const titles={financial:'Revenue & performance',listings:'Active listings',contacts:'Contacts & CRM',calendar:'Calendar & tasks',enquiries:'Latest enquiries',buyers:'Buyer engagement',market:'Market activity',pipeline:'Sales pipeline',propertymgmt:'Property management',marketing:'Marketing performance'};
  function detailHTML(){return detail==='listings'?detailListings():detail==='financial'?detailFinancial():detail==='contacts'||detail==='enquiries'||detail==='buyers'?peoplePanel(detail):detail==='pipeline'?detailPipeline():detail==='market'?detailMarket():detail==='propertymgmt'?detailPM():detail==='marketing'?detailMarketing():detail==='calendar'?detailCalendar():'';}
  function mountDetails(){const root=document.querySelector('.v16-detail-content');if(!root)return;root.innerHTML=detailHTML();const reduce=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;if(!reduce){root.querySelectorAll('[data-v16-count]').forEach(el=>{const number=Number(el.dataset.v16Count)||0;if(number<1)return;const before=performance.now(),dur=620;const format=v=>el.dataset.prefix+Math.round(v).toLocaleString('en-AU')+el.dataset.suffix;const animate=at=>{if(!el.isConnected)return;const f=Math.min(1,(at-before)/dur);el.textContent=format(number*(1-Math.pow(1-f,3)));if(f<1)requestAnimationFrame(animate);};requestAnimationFrame(animate);});}
    const rows=root.querySelectorAll('.v16-select-row');rows.forEach(el=>{el.classList.add('v16-list-reveal')});}
  function openPanel(name){if(!titles[name])return false;detail=name;detailIndex=0;detailTab=name==='financial'?'revenue':name==='market'?'enquiries':'all';modal(titles[name],'<div class="v16-detail-content"></div>',true);document.querySelector('#active-dialog')?.classList.add('v16-detail-dialog');mountDetails();return true;}
  document.addEventListener('click',e=>{
    const b=e.target.closest('[data-v16]');if(!b)return;
    e.preventDefault();e.stopImmediatePropagation();const name=b.dataset.v16,id=b.dataset.id;
    if(name==='add-module'){insertModule(id,layout().length);return;}
    if(name==='remove-module'){removeModule(id,true);return;}
    if(name==='move-up'||name==='move-down'){const ids=layout(),i=ids.indexOf(id),j=i+(name==='move-up'?-1:1);if(j<0||j>=ids.length)return;[ids[i],ids[j]]=[ids[j],ids[i]];save(ids);rerenderEditor();rerenderDashboard();return;}
    if(name==='category'){editorCategory=b.dataset.category||'All';rerenderEditor();return;}
    if(name==='undo-removal'){if(lastRemoved){const copy=lastRemoved;lastRemoved=null;const ids=layout(copy.view);ids.splice(copy.index,0,copy.id);save(ids,copy.view);rerenderEditor();}return;}
    if(name==='reset-layout'){save(defaults[role()]);lastRemoved=null;rerenderEditor();return;}
    if(name==='save-layout'){toast('Dashboard layout saved in this browser.');navigate('dashboard');return;}
    if(name==='preview-dashboard'){navigate('dashboard');return;}
    if(name==='listing-next'||name==='listing-prev'||name==='listing-pick'){detailIndex=name==='listing-pick'?Number(b.dataset.index):stepIndex(detailIndex+(name==='listing-next'?1:-1),DEMO_LISTINGS.length);mountDetails();return;}
    if(name==='select-person'||name==='select-stage'||name==='select-campaign'||name==='select-event'){detailIndex=Number(b.dataset.index)||0;mountDetails();return;}
    if(name==='stage-next'||name==='stage-prev'){detailIndex=Math.min(DEMO_PIPELINE.length-1,Math.max(0,detailIndex+(name==='stage-next'?1:-1)));mountDetails();return;}
    if(name==='detail-tab'){detailTab=b.dataset.tab;detailIndex=0;mountDetails();return;}
  },true);
  document.addEventListener('input',e=>{if(e.target.id==='v16-library-search')updateLibrarySearch(e.target.value);});
  document.addEventListener('keydown',e=>{
    const list=e.target.closest('[data-v16-animated-list]');if(!list||!['ArrowDown','ArrowUp','Home','End'].includes(e.key))return;
    const rows=[...list.querySelectorAll('[data-v16="select-person"],[data-v16="select-event"]')];if(!rows.length)return;
    e.preventDefault();const current=rows.indexOf(document.activeElement);let next=e.key==='Home'?0:e.key==='End'?rows.length-1:e.key==='ArrowDown'?Math.min(rows.length-1,current+1):Math.max(0,current-1);rows[next].focus();rows[next].scrollIntoView({block:'nearest'});
  });
  window.ReHubV15.shell=shell;
  window.ReHubV15.dashboardPage=dashboardPage;
  window.ReHubV16={editorPage,openPanel,layout,save,catalog};
})();
