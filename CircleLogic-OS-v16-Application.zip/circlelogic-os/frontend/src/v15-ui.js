/* Real Estate Hub 15.0. Frontend presentation layer only; all v14 backend calls are retained. */
'use strict';
(function () {
  const ic = (name, size=18) => window.icon(name,size);
  const safe = value => String(value??'').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const trim = (value,max=42) => String(value||'').length>max?String(value).slice(0,max-1)+'…':String(value||'');
  const money = value => '$'+new Intl.NumberFormat('en-AU').format(value);
  function view(){
    if(!S.v15View){try{S.v15View=localStorage.getItem('cl-v15-view')==='agent'?'agent':'principal';}catch{S.v15View='principal';}}
    return S.v15View;
  }
  function navButton(text,iconName,part){return `<button type="button" class="nav-button v15-nav-button" data-action="open-panel" data-panel="${part}"><span class="nav-icon">${ic(iconName)}</span><span class="nav-label">${safe(text)}</span></button>`;}
  function shell(){
    const account=S.user?.username||S.user?.email||'Account';
    const initial=account.slice(0,1).toUpperCase();
    const collapsed=S.sidebarCollapsed?'collapsed':'';
    const isPrincipal=view()==='principal';
    const pageName=S.route==='integrations'?'API Connections':'Real Estate Hub';
    document.querySelector('#app').innerHTML=`
      <aside class="sidebar v15-sidebar ${collapsed}" aria-label="Main navigation">
        <div class="sidebar-top">
          <div class="sidebar-brand-row">
            <div class="brand"><span class="v15-logo"><img src="/assets/circlelogic-logo-original.svg" alt="" width="30" height="30"></span><div class="brand-copy"><strong>CircleLogic</strong><span class="sub">REAL ESTATE HUB</span></div></div>
            <button class="icon-btn collapse-toggle" data-action="collapse-sidebar" title="${S.sidebarCollapsed?'Expand':'Collapse'} sidebar" aria-label="${S.sidebarCollapsed?'Expand':'Collapse'} sidebar">${ic('chevron',16)}</button>
          </div>
          <nav class="sidebar-nav" aria-label="Workspace navigation">
            <button class="nav-button v15-nav-button ${S.route==='dashboard'?'active':''}" data-nav="dashboard" ${S.route==='dashboard'?'aria-current="page"':''}><span class="nav-icon">${ic('grid')}</span><span class="nav-label">Dashboard</span></button>
            <div class="v15-nav-divider"></div>
            ${navButton('Listings','home','listings')}
            ${navButton('Enquiries','mail','enquiries')}
            ${navButton('Buyers','users','buyers')}
            ${navButton('Contacts','contract','contacts')}
            ${navButton('Sales pipeline','chart','pipeline')}
            ${navButton('Financials','money','financial')}
            ${navButton('Property management','building','propertymgmt')}
            ${navButton('Market insights','pulse','market')}
            ${navButton('Marketing','megaphone','marketing')}
            ${navButton('Calendar','calendar','calendar')}
            <div class="v15-nav-divider"></div>
            <button class="nav-button v15-nav-button ${S.route==='integrations'?'active':''}" data-nav="integrations" ${S.route==='integrations'?'aria-current="page"':''}><span class="nav-icon">${ic('plug')}</span><span class="nav-label">API Connections</span></button>
            <button class="nav-button v15-nav-button" data-action="new-module"><span class="nav-icon">${ic('plus')}</span><span class="nav-label">New modules</span></button>
          </nav>
        </div>
        <div class="sidebar-bottom v15-sidebar-bottom">
          <button class="nav-button v15-nav-button" data-action="security"><span class="nav-icon">${ic('settings')}</span><span class="nav-label">Account settings</span></button>
          <div class="v15-sidebar-profile"><span class="v15-avatar" aria-hidden="true">${safe(initial)}</span><div class="profile-copy"><strong>${safe(account)}</strong><small>${safe(S.user?.agency||'Workspace')}</small></div><button class="icon-btn v15-logout" data-action="logout" aria-label="Sign out">${ic('logout',16)}</button></div>
          <span class="v15-release-label">Frontend v15.0 · v14 backend</span>
        </div>
      </aside>
      <main class="main v15-main ${collapsed}">
        <header class="topbar v15-topbar">
          <div class="v15-topbar-left"><button class="icon-btn mobile-menu" data-action="toggle-menu" aria-label="Toggle navigation" aria-expanded="false">${ic('menu',20)}</button><h1>${safe(pageName)}</h1></div>
          <div class="v15-topbar-right">
            <button class="v15-search-trigger" data-v15="search" aria-label="Search properties, contacts, buyers and connections">${ic('search',17)}<span>Search properties, buyers, contacts...</span><kbd>Ctrl K</kbd></button>
            <div class="v15-view-switch" aria-label="Dashboard view"><button data-v15="role" data-role="principal" class="${isPrincipal?'active':''}" aria-pressed="${isPrincipal}">Principal</button><button data-v15="role" data-role="agent" class="${!isPrincipal?'active':''}" aria-pressed="${!isPrincipal}">Agent</button></div>
            <button class="icon-btn v15-notify" data-action="connection-health" aria-label="Connection status">${ic('bell',19)}<i></i></button>
            <button class="v15-account" data-action="security" aria-label="Account security"><span class="v15-avatar">${safe(initial)}</span><span class="v15-account-name">${safe(account)}</span>${ic('down',14)}</button>
          </div>
        </header>
        ${S.preview?`<div class="preview-strip"><span>${S.example?'Sample data':'Interactive preview'} · This page does not connect to real accounts.</span><div class="segmented"><button data-action="preview-empty" class="${!S.example?'active':''}">Empty</button><button data-action="preview-example" class="${S.example?'active':''}">Example</button></div></div>`:''}
        <div class="content v15-content" id="page"><div class="loading">Loading workspace...</div></div>
      </main>`;
  }
  const kpiSeries = [28,31,30,36,35,43,41,47,44,53,48,59];
  function sparkline(data,color){
    const nums=data.map(Number);const low=Math.min(...nums),max=Math.max(...nums);const points=nums.map((n,i)=>[4+(i/(nums.length-1))*108,34-((n-low)/(max-low||1))*24]);
    const line=points.map(([x,y])=>`${x.toFixed(1)},${y.toFixed(1)}`).join(' ');
    return `<svg viewBox="0 0 116 40" width="100%" height="40" aria-hidden="true"><polyline points="${line}" fill="none" stroke="${color}" stroke-width="2.3" stroke-linejoin="round" stroke-linecap="round"/><circle cx="${points.at(-1)[0]}" cy="${points.at(-1)[1]}" r="2.3" fill="${color}"/></svg>`;
  }
  function kpi(label,value,delta,iconName,panel,tone,series=kpiSeries){return `<button class="v15-kpi v15-kpi-${tone}" data-action="open-panel" data-panel="${panel}"><span class="v15-kpi-icon">${ic(iconName,18)}</span><span class="v15-kpi-title">${safe(label)}</span><strong class="v15-kpi-value">${safe(value)}</strong><span class="v15-kpi-delta">${safe(delta)}</span><span class="v15-kpi-spark">${sparkline(series,{'blue':'#499bff','green':'#28d2a3','purple':'#a37afe','orange':'#f4a24e','cyan':'#31cbd2'}[tone])}</span></button>`;}
  function metrics(){
    const agent=view()==='agent';
    if(agent)return [
      kpi('Buyer contacts',String(DEMO_BUYERS.length),'Assigned view · sample','users','buyers','blue'),
      kpi('New enquiries',statValue('enquiries'),'Current reporting period','mail','enquiries','purple',DEMO_MARKET_TRENDS.map(x=>x.enquiries)),
      kpi('Active listings',statValue('listings'),'Sales inventory','home','listings','green'),
      kpi('Pipeline GCI',DEMO_KPIS.pipeline,'Agency sample','money','pipeline','orange'),
      kpi('Appointments',S.data?.calendar?.total===null?'—':String(S.data?.calendar?.total??'—'),'Live when connected','calendar','calendar','cyan')
    ].join('');
    return [
      kpi('Revenue MTD',DEMO_KPIS.revenue,'89.5% of target','money','financial','blue',DEMO_FINANCIALS.months.map(x=>x.value)),
      kpi('Pipeline GCI',DEMO_KPIS.pipeline,'Agency opportunities','chart','pipeline','purple'),
      kpi('New enquiries',statValue('enquiries'),'Current reporting period','mail','enquiries','green',DEMO_MARKET_TRENDS.map(x=>x.enquiries)),
      kpi('Active listings',statValue('listings'),'Available stock','home','listings','orange'),
      kpi('Properties managed',DEMO_KPIS.managed,'Agency portfolio','building','propertymgmt','cyan')
    ].join('');
  }
  function head(title,code,buttonLabel='View all'){
    return `<div class="v15-module-head"><div class="v15-module-title">${code?`<span class="v15-section-icon">${ic(code,18)}</span>`:''}<h2>${safe(title)}</h2></div><button class="v15-view-all" data-action="open-panel" data-panel="${{ 'Revenue performance':'financial','Recent listings':'listings','Latest enquiries':'enquiries','Tasks & upcoming':'calendar','Buyer engagement':'buyers','Market activity':'market','Sales pipeline':'pipeline','Contacts & CRM':'contacts','Property management':'propertymgmt','Marketing performance':'marketing'}[title]||'financial'}">${safe(buttonLabel)} ${ic('chevron',13)}</button></div>`;
  }
  function svgLine(nums,width,height,min,max){
    const x=i=>i*width/(nums.length-1);const y=n=>height-(n-min)/(max-min||1)*height;
    const p=nums.map((n,i)=>[x(i),y(n)]);
    let path=`M ${p[0][0].toFixed(2)} ${p[0][1].toFixed(2)}`;
    for(let i=0;i<p.length-1;i++){
      const a=p[Math.max(0,i-1)],b=p[i],c=p[i+1],d=p[Math.min(p.length-1,i+2)];
      const c1x=b[0]+(c[0]-a[0])/6,c1y=b[1]+(c[1]-a[1])/6,c2x=c[0]-(d[0]-b[0])/6,c2y=c[1]-(d[1]-b[1])/6;
      path+=` C ${c1x.toFixed(1)} ${c1y.toFixed(1)} ${c2x.toFixed(1)} ${c2y.toFixed(1)} ${c[0].toFixed(1)} ${c[1].toFixed(1)}`;
    }
    return {path,points:p};
  }
  function financeGraph(){
    const records=DEMO_FINANCIALS.months;const vals=records.map(x=>Number(x.value));const target=DEMO_FINANCIALS.target/1000;const graph=svgLine(vals,500,168,0,350);
    const area=graph.path+` L 500 168 L 0 168 Z`;
    return `<div class="v15-graph-summary"><strong>${safe(DEMO_KPIS.revenue)}</strong><span class="v15-positive">${ic('up',14)} 89.5% of target</span></div><div class="v15-graph-wrap"><svg class="v15-revenue-chart" viewBox="0 0 570 228" role="img" aria-label="Illustrative monthly revenue from May to September, compared with monthly target"><defs><linearGradient id="v15-finance-fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#338df7" stop-opacity=".27"/><stop offset="1" stop-color="#338df7" stop-opacity="0"/></linearGradient></defs>
      <g transform="translate(51 15)">${[0,80,160,240,320].map(t=>`<line x1="0" y1="${(168-t/350*168).toFixed(1)}" x2="500" y2="${(168-t/350*168).toFixed(1)}" stroke="#263242" stroke-width="1"/><text x="-12" y="${(172-t/350*168).toFixed(1)}" text-anchor="end" fill="#8491a6" font-size="11">$${t}k</text>`).join('')}
      <line x1="0" y1="${(168-target/350*168).toFixed(1)}" x2="500" y2="${(168-target/350*168).toFixed(1)}" stroke="#6e7a92" stroke-dasharray="5 6" stroke-width="1.5"/>
      <path d="${area}" fill="url(#v15-finance-fill)"/><path d="${graph.path}" fill="none" stroke="#479bff" stroke-width="3.2" stroke-linejoin="round" stroke-linecap="round"/>${graph.points.map((p,i)=>`<circle cx="${p[0].toFixed(1)}" cy="${p[1].toFixed(1)}" r="4" fill="#101925" stroke="#74b9ff" stroke-width="2"><title>${safe(records[i].label)}: $${safe(records[i].value)}k</title></circle>`).join('')}
      ${records.map((r,i)=>`<text x="${i*125}" y="194" text-anchor="middle" font-size="11" fill="#8491a6">${safe(r.label)}</text>`).join('')}</g></svg></div><div class="v15-chart-legend"><span><i class="v15-legend-dot blue"></i>Revenue</span><span><i class="v15-legend-line"></i>Monthly target</span><span class="v15-chart-note">Illustrative financials</span></div>`;
  }
  function revenuePanel(){return `<section class="v15-module v15-chart-panel" aria-label="Revenue performance">${head('Revenue performance','chart')}<div class="v15-chart-content">${financeGraph()}</div></section>`;}
  function listingImg(i){return `/assets/property-preview-${1+i%3}.webp`;}
  function galleryContents(){
    const i=Number(S.v15Gallery||0);const count=DEMO_LISTINGS.length;const indexes=[i%count,(i+1)%count];
    return indexes.map(j=>{const p=DEMO_LISTINGS[j];const status=j%3===1?'Under offer':j%3===2?'Coming soon':'For sale';return `<button class="v15-property" data-action="demo-record" data-kind="listings" data-index="${j}"><span class="v15-property-photo"><img src="${listingImg(j)}" alt="Illustrative house photograph" loading="lazy"><span class="v15-property-status ${j%3===1?'offer':j%3===2?'soon':''}">${status}</span></span><span class="v15-property-info"><strong>${safe(p.title)}</strong><small>${safe(p.suburb)} · ${safe(p.summary)}</small><b>${safe(p.price)}</b><span class="v15-property-stage">${safe(trim(p.stage,32))}</span></span></button>`;}).join('');
  }
  function propertyPanel(){return `<section class="v15-module v15-property-panel" aria-label="Recent listings">${head('Recent listings','home')}<div class="v15-gallery" data-v15-gallery>${galleryContents()}</div><div class="v15-gallery-controls"><span>${safe(String((S.v15Gallery||0)+1).padStart(2,'0'))} / ${safe(String(DEMO_LISTINGS.length).padStart(2,'0'))}</span><div><button data-v15="gallery-prev" aria-label="Previous properties">${ic('chevron',17)}</button><button data-v15="gallery-next" aria-label="Next properties">${ic('chevron',17)}</button></div></div></section>`;}
  function enquiriesPanel(){return `<section class="v15-module v15-enquiries" aria-label="Latest enquiries">${head('Latest enquiries','mail')}<div class="v15-enquiry-list">${DEMO_ENQUIRIES.slice(0,5).map((p,i)=>`<button class="v15-enquiry" data-action="open-panel" data-panel="enquiries"><span class="v15-person v15-person-${i%5}">${safe(initials(p.name))}</span><span class="v15-enquiry-name"><strong>${safe(p.name)}</strong><small>${safe(p.property)}</small></span><span class="v15-enquiry-message">${safe(p.intent)} <small>${safe(p.source)}</small></span><time>${safe(p.received)}</time><span class="v15-lead-status ${i<2?'fresh':''}">${i<2?'New':'In progress'}</span></button>`).join('')}</div></section>`;}
  function calendarPanel(){
    const rows=(S.data?.calendar?.rows||[]).map((r,i)=>({...r,index:i})).filter(r=>{const when=dateObj(r.start,r.timezone);return when&&when.getTime()<=Date.now()+S.days*86400000;}).slice(0,5);
    const real=S.data?.calendar?.total!==null&&S.data?.calendar?.total!==undefined;
    let content='';
    if(real&&rows.length){content=`<div class="v15-agenda">${rows.map((r,i)=>{const when=dateObj(r.start,r.timezone);const time=r.all_day?'All day':fmtDate(when,{hour:'numeric',minute:'2-digit'});return `<button class="v15-agenda-item" data-action="record" data-panel="calendar" data-index="${r.index}"><span class="v15-agenda-time">${safe(time)}</span><span class="v15-agenda-mark v15-mark-${i%5}"></span><span class="v15-agenda-copy"><strong>${safe(r.title)}</strong><small>${safe(r.location||r.calendar_source||'Calendar event')}</small></span>${ic('chevron',13)}</button>`;}).join('')}</div>`;}
    else if(real){content=`<div class="v15-calendar-empty">${ic('calendar',28)}<strong>No upcoming appointments</strong><span>Your connected calendar has no events in the next ${S.days} days.</span><button data-action="open-panel" data-panel="calendar">Open calendar</button></div>`;}
    else{content=`<div class="v15-calendar-empty">${ic('calendar',29)}<strong>Connect your calendar</strong><span>Appointments will appear here after Google Calendar is connected and synced.</span><button data-connect="google">Connect Google Calendar ${ic('arrow',14)}</button></div>`;}
    return `<section class="v15-module v15-calendar" aria-label="Tasks and upcoming appointments">${head('Tasks & upcoming','calendar','Calendar')}${real?`<div class="v15-calendar-window"><label for="calendar-window">Show events</label><select id="calendar-window" aria-label="Calendar time range"><option value="7" ${S.days===7?'selected':''}>Next 7 days</option><option value="30" ${S.days===30?'selected':''}>Next 30 days</option></select></div>`:''}${content}</section>`;
  }
  function buyerPanel(){return `<section class="v15-module" aria-label="Buyer engagement">${head('Buyer engagement','users')}<div class="v15-table-head v15-buyer-cols"><span>Buyer</span><span>Engagement</span><span>Budget</span></div>${DEMO_BUYERS.slice(0,5).map((p,i)=>`<button class="v15-buyer-row v15-buyer-cols" data-action="demo-record" data-kind="buyers" data-index="${i}"><span class="v15-person-cell"><span class="v15-person v15-person-${i%5}">${safe(initials(p.title))}</span><span><strong>${safe(p.title)}</strong><small>${safe(p.suburb)}</small></span></span><span class="v15-engage"><span class="v15-progress"><i style="width:${Math.max(0,Math.min(100,p.score))}%;background:${scoreColor(p.score)}"></i></span><b>${safe(p.score)}</b></span><span class="v15-budget">${safe(p.budget)}</span></button>`).join('')}</section>`;}
  function marketPanel(){
    const arr=DEMO_MARKET_TRENDS;const vals=arr.map(p=>p.enquiries);const sales=arr.map(p=>p.listings);
    const l1=svgLine(vals,500,154,0,30),l2=svgLine(sales,500,154,0,30);
    return `<section class="v15-module" aria-label="Market activity">${head('Market activity','pulse')}<div class="v15-chart-legend v15-market-legend"><span><i class="v15-legend-dot blue"></i>Enquiries</span><span><i class="v15-legend-dot green"></i>New listings</span><span>Last 7 days</span></div><div class="v15-graph-wrap"><svg viewBox="0 0 568 215" width="100%" role="img" aria-label="Illustrative market enquiries and listings for each day"><g transform="translate(36 10)">${[0,10,20,30].map(y=>`<line x1="0" y1="${(154-y/30*154).toFixed(1)}" x2="500" y2="${(154-y/30*154).toFixed(1)}" stroke="#263242"/><text x="-12" y="${(159-y/30*154).toFixed(1)}" text-anchor="end" fill="#8e9db0" font-size="11">${y}</text>`).join('')}<path d="${l1.path}" fill="none" stroke="#4194fb" stroke-width="3"/><path d="${l2.path}" fill="none" stroke="#35cfa7" stroke-width="3"/>${arr.map((d,i)=>`<text x="${(i*500/6).toFixed(1)}" y="182" fill="#8e9db0" font-size="11" text-anchor="middle">${safe(d.label)}</text>`).join('')}</g></svg></div><div class="v15-market-stats"><span><strong>6</strong> Suburbs tracked</span><span><strong>${arr.reduce((a,x)=>a+x.enquiries,0)}</strong> Enquiries</span><span><strong>${arr.reduce((a,x)=>a+x.listings,0)}</strong> New listings</span></div></section>`;
  }
  function pipelinePanel(){const max=Math.max(...DEMO_PIPELINE.map(x=>x.deals));return `<section class="v15-module" aria-label="Sales pipeline">${head('Sales pipeline','chart')}<div class="v15-stage-list">${DEMO_PIPELINE.slice(0,5).map((p,i)=>`<button class="v15-stage" data-action="open-panel" data-panel="pipeline"><span>${safe(p.stage)}</span><span class="v15-stage-bar"><i style="width:${Math.round(p.deals/max*100)}%;background:${['#4c9df9','#9b75f5','#29bcab','#f3a34e','#5f99fa'][i]}"></i></span><strong>${safe(p.deals)}</strong><small>${safe(p.gci)}</small></button>`).join('')}</div></section>`;}
  function contactsPanel(){return `<section class="v15-module" aria-label="Contacts and CRM">${head('Contacts & CRM','contract')}<div class="v15-table-head v15-contact-cols"><span>Contact</span><span>Role</span><span>Status</span></div>${DEMO_CONTACTS.slice(0,5).map((p,i)=>`<button class="v15-contact-row v15-contact-cols" data-action="demo-record" data-kind="contacts" data-index="${i}"><span class="v15-person-cell"><span class="v15-person v15-person-${i%5}">${safe(initials(p.title))}</span><span><strong>${safe(p.title)}</strong><small>${safe(p.suburb)}</small></span></span><span class="v15-muted-cell">${safe(p.role)}</span><span class="v15-small-tag">${safe(p.status)}</span></button>`).join('')}</section>`;}
  function pmPanel(){return `<section class="v15-module" aria-label="Property management">${head('Property management','building')}<div class="v15-pm-grid">${DEMO_PM_STATS.slice(0,4).map((p,i)=>`<button class="v15-pm-stat" data-action="open-panel" data-panel="propertymgmt"><span>${safe(p.label)}</span><strong>${safe(p.value)}</strong><small>${safe(p.detail)}</small></button>`).join('')}</div></section>`;}
  function marketingPanel(){return `<section class="v15-module" aria-label="Marketing performance">${head('Marketing performance','megaphone')}<div class="v15-table-head v15-marketing-cols"><span>Campaign</span><span>Views</span><span>Enquiries</span><span>CPL</span></div>${DEMO_MARKETING.slice(0,5).map(p=>`<button class="v15-marketing-row v15-marketing-cols" data-action="open-panel" data-panel="marketing"><strong>${safe(p.campaign)}</strong><span>${safe(p.views)}</span><span>${safe(p.enquiries)}</span><span>${safe(p.cpl)}</span></button>`).join('')}</section>`;}
  function dashboardPage(){
    const agent=view()==='agent';
    const main=agent?[enquiriesPanel(),calendarPanel(),propertyPanel(),buyerPanel(),revenuePanel(),marketPanel(),pipelinePanel(),contactsPanel(),pmPanel(),marketingPanel()]
      :[revenuePanel(),propertyPanel(),enquiriesPanel(),calendarPanel(),buyerPanel(),marketPanel(),pipelinePanel(),contactsPanel(),pmPanel(),marketingPanel()];
    const today=new Intl.DateTimeFormat('en-AU',{timeZone:'Australia/Sydney',day:'numeric',month:'short',year:'numeric'}).format(new Date());
    return `<div class="v15-overview-line"><div><h2>${agent?'Agent overview':'Agency overview'}</h2><span class="v15-quiet-sub">${safe(today)}</span></div><button class="v15-refresh" data-action="refresh" title="Refresh connected data">${ic('refresh',15)} Refresh</button></div><div class="v15-kpis">${metrics()}</div><div class="v15-modules">${main.join('')}</div><section class="v15-add-module"><span>${ic('plus',18)} More modules</span><button data-action="new-module">Add module ${ic('arrow',14)}</button></section><footer class="v15-footer">CircleLogic Real Estate Hub <span>Frontend v15.0 · ${S.preview?'Interactive preview':'Operational prototype'}</span></footer>`;
  }
  function showSearch(){
    modal('Search workspace',`<form id="v15-search-form" class="v15-search-form"><label for="v15-search-input">Search contacts, listings, buyers and connectors</label><div class="v15-search-input-wrap">${ic('search',20)}<input id="v15-search-input" name="query" placeholder="Start typing..." autocomplete="off" autofocus></div></form><div id="v15-search-results" class="v15-search-results"></div>`,true);
    const input=document.querySelector('#v15-search-input');input?.focus();renderSearch('');
  }
  function renderSearch(q){
    const root=document.querySelector('#v15-search-results');if(!root)return;
    const entries=[
      ...DEMO_LISTINGS.map((p,i)=>({text:p.title,sub:`Listing · ${p.suburb}`,action:'demo-record',kind:'listings',index:i})),
      ...DEMO_BUYERS.map((p,i)=>({text:p.title,sub:`Buyer · ${p.suburb}`,action:'demo-record',kind:'buyers',index:i})),
      ...DEMO_CONTACTS.map((p,i)=>({text:p.title,sub:`Contact · ${p.role}`,action:'demo-record',kind:'contacts',index:i})),
      ...S.integrations.map(p=>({text:p.name,sub:'API connection',action:'open-connector',provider:p.id}))
    ];
    const term=q.toLowerCase().trim();const matched=term?entries.filter(x=>(x.text+' '+x.sub).toLowerCase().includes(term)).slice(0,14):entries.slice(0,9);
    root.innerHTML=matched.length?matched.map(x=>`<button class="v15-search-result" ${x.action==='open-connector'?`data-connect="${safe(x.provider)}"`:`data-action="demo-record" data-kind="${safe(x.kind)}" data-index="${x.index}"`}><span><strong>${safe(x.text)}</strong><small>${safe(x.sub)}</small></span>${ic('arrow',16)}</button>`).join(''):'<div class="v15-search-empty">No matching records</div>';
  }
  document.addEventListener('click',ev=>{
    const b=ev.target.closest('[data-v15]');if(!b)return;
    ev.preventDefault();ev.stopImmediatePropagation();
    const kind=b.dataset.v15;
    if(kind==='role'){
      if(S.route!=='dashboard')S.route='dashboard';S.v15View=b.dataset.role;
      try{localStorage.setItem('cl-v15-view',S.v15View);}catch{}
      if(location.hash!=='#dashboard')history.replaceState(null,'','#dashboard');
      window.ReHubV15.shell();document.querySelector('#page').innerHTML=window.ReHubV15.dashboardPage();
    }
    if(kind==='search')showSearch();
    if(kind==='gallery-prev'||kind==='gallery-next'){
      S.v15Gallery=((Number(S.v15Gallery||0)+(kind==='gallery-next'?1:-1)+DEMO_LISTINGS.length)%DEMO_LISTINGS.length);
      const gallery=document.querySelector('[data-v15-gallery]');if(gallery){gallery.innerHTML=galleryContents();const count=gallery.parentElement.querySelector('.v15-gallery-controls>span');if(count)count.textContent=String(S.v15Gallery+1).padStart(2,'0')+' / '+String(DEMO_LISTINGS.length).padStart(2,'0');}
    }
  },true);
  document.addEventListener('input',ev=>{if(ev.target.id==='v15-search-input')renderSearch(ev.target.value);});
  document.addEventListener('keydown',ev=>{if((ev.ctrlKey||ev.metaKey)&&ev.key.toLowerCase()==='k'&&S.user){ev.preventDefault();showSearch();}});
  document.addEventListener('submit',ev=>{if(ev.target.id==='v15-search-form'){ev.preventDefault();renderSearch(ev.target.query.value);}},true);
  window.ReHubV15={shell,dashboardPage,showSearch,footer:()=>`<footer class="v15-footer">CircleLogic Real Estate Hub <span>Frontend v15.0 · v14 backend</span></footer>`};
})();
