#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ ! -f "frontend/src/v16-ui.js" ] || [ ! -f "frontend/src/v16-style.css" ] || ! grep -q '0.16.0' VERSION; then
  printf '%s\n' 'This is not a complete Real Estate Hub v16.0 folder. Extract the full ZIP first.'
  exit 1
fi
printf '\nReal Estate Hub: frontend v16.0 / original v14 backend\n'
printf '%s\n' 'Close previous CircleLogic servers before starting. Look for Frontend v16.0 on sign-in.'
if command -v python3 >/dev/null 2>&1; then
  python3 launcher.py start
else
  printf '%s\n' 'Python 3.11+ required.'
  exit 1
fi
