# Real Estate Hub v16.0

Start with **README-v16.md** for Windows/macOS launch and frontend-only update instructions.

This release uses the original CircleLogic OS v14 backend, including the same account security, plugins and Google Calendar integration. Only the frontend has been redesigned.

On Windows, use `START-V16.cmd`. Verify the login screen says **Frontend v16.0**.

Do not upload agency or client data to unapproved services.
