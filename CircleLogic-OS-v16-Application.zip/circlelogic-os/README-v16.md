# Real Estate Hub v16.0 | Dashboard redesign and module interactions

This is a **frontend-only redesign** based on v15 with the **original v14 backend**. No backend code, database schema, connector API, authentication/2FA, or Google Calendar integration has been modified. v14 remains the functional baseline. The Principal/Agent control selects separate prototype layouts; it **does not change permissions or enforce user-specific data access**.

## Start the full application

1. Close any old CircleLogic server windows. Only one server can use the configured local port.
2. Extract `CircleLogic-OS-v16-Application.zip` into a new folder. Inside that folder open `circlelogic-os`.
3. Launch `START-V16.cmd` on Windows, or `START-V16.command` on macOS. `START-CIRCLELOGIC.cmd` still works.
4. Sign in using the existing application flow (including 2FA).
5. Verify **Frontend v16.0** appears on the sign-in screen and the sidebar footer. If not, check the server/window/folder before reporting a front-end failure. Refresh/reopen the browser after server restarts.

**Important:** A clean installation is a separate local app instance. It does not automatically import an existing local `.env`, database or saved credentials. For continued use of an existing agency test workspace, back it up and apply the frontend-only update instead.

## Frontend-only update to an existing v14/v15 copy

1. Back up the **entire existing installation folder**, including the database and configuration, before applying any updates.
2. Stop the running server. Extract `CircleLogic-OS-v16-Frontend-Only-Update.zip` **into the directory that contains the `circlelogic-os` folder** (not directly inside `circlelogic-os`), allowing files under `circlelogic-os/frontend/` to replace older frontend files.
3. Open the updated `circlelogic-os` folder and use `START-V16.cmd`, which verifies the v16 assets and `VERSION` are present.
4. Reopen the app in a fresh browser window after restart and verify **Frontend v16.0**.

This update contains no `backend/` files and no `.env`, database, or tenant/credential data.

## Interface and interactions

- Only three primary sidebar destinations: **Dashboard**, **Plugins**, **New module**. User account and logout remain available from the user/profile controls.
- Original full-colour CircleLogic SVG logo, refined dark design and responsive two-column dashboard. Five v14 KPIs remain. All ten v14 functional modules remain accessible, with layout chosen separately for Principal and Agent.
- Expanded modules are purpose-built interactive workspaces (not generic list dialogs): listings carousel and performance; selectable contact, enquiry and buyer activity; financial and market charts; sales pipeline stages; marketing; property management; and live Google Calendar events.
- **New module** opens a layout editor. Reorder by dragging module handles or using keyboard-accessible move controls. Add from the module library. Remove by dragging a module to the red outlined bin (animated shred), or use the remove action. Undo and reset are provided.
- Layout selections persist in **browser-local storage** by presentation view, not server-side, so changes apply to that browser/profile only. Removing a module does **not** delete data or revoke its connector.
- Interactions were adapted to the existing vanilla-JavaScript frontend using the **ideas and patterns** in the supplied React Bits components (AnimatedList, Carousel, Counter and Stepper). These are not drop-in original React implementations. Decorative Glass/Dock/Folder/Lightfall effects were intentionally excluded from the working dashboard to preserve readability and performance.
- Existing data remains the same v14/v15 source. Demo financials, people and illustrative listing photographs are not live third-party data. Calendar only shows actually connected events; no sample appointments are substituted in the live application.

## Preserved functionality

- Original v14 backend untouched, including login and 2FA, tenancy, account security, and provider APIs.
- **33 plugins/connectors**, credential entry guides, connection status and diagnostics.
- Google Calendar's approved OAuth and read-only sync. Imported calendar events open the existing event detail flow. No calendar integration is activated automatically in a fresh installation.
- Existing module details and actions reachable within the redesigned interface, global search, and responsive small-screen layout.

## Interactive standalone preview

`CircleLogic-OS-v16-Interactive-Preview.html` is a **static demo** with fictional sample data and no live backend or sign-in. It does not connect Google Calendar, does not save to any production account and must not be used for credentials. Use the full application for functional testing.

## Verification

39 UI interaction checks passed with a real backend-authenticated Chromium test harness (including password and MFA), covering module detail views, edits, drag-to-bin/remove/undo, role layouts, 33 connectors, synthetic calendar-event rendering, search and mobile. Backend source files are byte-identical to v14. Some historical generic backend tests have legacy connector-order/validation expectations; the frontend release does not alter that behaviour.
