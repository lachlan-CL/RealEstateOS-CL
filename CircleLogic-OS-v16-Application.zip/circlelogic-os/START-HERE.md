# Start Real Estate Hub v16.0

1. Extract the complete ZIP, open the `circlelogic-os` folder.
2. Close older CircleLogic server processes.
3. Run `START-V16.cmd` on Windows or `START-V16.command` on macOS.
4. Sign in as usual. Check **Frontend v16.0** on the sign-in page and sidebar.

For updating an existing v14/v15 installation and retaining the local database, read `README-v16.md` and use the frontend-only update ZIP after backing up.
