"""CircleLogic OS application package."""
