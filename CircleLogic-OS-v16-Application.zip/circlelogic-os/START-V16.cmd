@echo off
setlocal
cd /d "%~dp0"
if not exist "frontend\src\v16-ui.js" (
  echo This folder does not contain Real Estate Hub v16.0.
  echo Extract the FULL v16.0 ZIP into a new folder, then launch from there.
  pause
  exit /b 1
)
if not exist "frontend\src\v16-style.css" (
  echo The v16.0 frontend styles are missing. Re-extract the full application.
  pause
  exit /b 1
)
findstr /c:"0.16.0" VERSION >nul 2>nul
if errorlevel 1 (
  echo This folder does not report v16.0. Check which folder you extracted.
  pause
  exit /b 1
)
echo.
echo ==============================================================
echo REAL ESTATE HUB - FRONTEND v16.0 / ORIGINAL v14 BACKEND
echo ==============================================================
echo.
echo Close any previously running CircleLogic server window first.
echo Check for "Frontend v16.0" on the sign-in screen and in the sidebar.
echo.
where py >nul 2>nul
if not errorlevel 1 (
  py -3 launcher.py start
) else (
  python launcher.py start
)
if errorlevel 1 echo Startup failed. Check errors above. Do not open a stale browser tab.
echo.
pause
